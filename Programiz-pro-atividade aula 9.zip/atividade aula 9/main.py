import pandas as pd 
import matplotlib.pyplot as plt 

# carregamento do csv

df = pd.read_csv('dados.csv')
print('-----------------------------------')
print(df)

# mostrar as primeiras linhas
# população
# amostragem

print('-----------------------------------')
print(df.head())

# verificar se existe dados ausentes

print('-----------------------------------')
df.isnull().sum()

# eliminar as linhas vausentes

print('-----------------------------------')
df = df.dropna()

# verifica se estão corretos

print('-----------------------------------')
print(df.dtypes)

# estatistica

print('-----------------------------------')
print(df.describe())

# agrupar dados por produtos e somar a venda

vendas_por_mes = df.groupby('mes')['vendas'].max()

print('-----------------------------------')
print(vendas_por_mes)

# criar grafico

# barra - comparação

plt.bar(df['mes'],df['vendas'], color='green')
plt.title('VENDAS NOS MESES')
plt.xlabel('mes')
plt.ylabel('Total de Vendas')




plt.show()

# linhas - plot - evolução de um variavel ao longo do tempo

# df['datas'] = pd.to
# vendas = 

plt.plot(df['mes'],df['vendas'], color='green')
plt.title('VENDAS DOS PRODUTOS')
plt.xlabel('produto')
plt.ylabel('Total de Vendas')


plt.show()

#  dispersão - scatter - mostra a releção entre duas variaveis


plt.scatter(df['vendas'],df['lucro'], color='green')
plt.title('VENDAS DOS PRODUTOS')
plt.xlabel('produto')
plt.ylabel('Total de Vendas')

plt.show()

# pizza - pie - mostra a proporção em relação ao todo

# n = df[].head()
plt.pie(df['vendas'], labels = df['mes'], autopct ='%1.1f')
plt.title('GRAFICO DE PIZZA')

plt.show()

# quais produtos tem as maiores vendas totais

# as ven aumentam com o tempo

# existem relação entreo preço unitario e o total de vendas

# quais os dias da semana tem as maiores vendas